Flappy Bird — ZhangKwokHo
Individual assignment
Year 1 · Semester 2 · CIS243 — 2D Game Design and Development

Unreal Engine source project (EngineAssociation: 5.6).
Open Flappy_Bird.uproject in Unreal Engine 5.6.
The supplied gameplay level is Content/blueprints/Level/Level1.umap.
This is source material, not a browser build or standalone executable.
The portfolio does not claim a completed runtime test.
